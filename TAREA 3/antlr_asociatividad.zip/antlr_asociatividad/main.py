from antlr4 import *

# IZQUIERDA
from gramaticas.ExprIzqLexer import ExprIzqLexer
from gramaticas.ExprIzqParser import ExprIzqParser
from visitor import EvalVisitorIzq

# DERECHA
from gramaticas.ExprDerLexer import ExprDerLexer
from gramaticas.ExprDerParser import ExprDerParser
from visitor import EvalVisitorDer

# PRECEDENCIA NORMAL
from gramaticas.ExprPrecNormalLexer import ExprPrecNormalLexer
from gramaticas.ExprPrecNormalParser import ExprPrecNormalParser
from visitor import EvalVisitorPrecNormal

# PRECEDENCIA INVERTIDA
from gramaticas.ExprPrecInvertidaLexer import ExprPrecInvertidaLexer
from gramaticas.ExprPrecInvertidaParser import ExprPrecInvertidaParser
from visitor import EvalVisitorPrecInvertida


def evaluar_izq(archivo):
    input_stream = FileStream(archivo)
    lexer = ExprIzqLexer(input_stream)
    stream = CommonTokenStream(lexer)
    parser = ExprIzqParser(stream)
    return EvalVisitorIzq().visit(parser.prog())


def evaluar_der(archivo):
    input_stream = FileStream(archivo)
    lexer = ExprDerLexer(input_stream)
    stream = CommonTokenStream(lexer)
    parser = ExprDerParser(stream)
    return EvalVisitorDer().visit(parser.prog())


def evaluar_prec_normal(archivo):
    input_stream = FileStream(archivo)
    lexer = ExprPrecNormalLexer(input_stream)
    stream = CommonTokenStream(lexer)
    parser = ExprPrecNormalParser(stream)
    return EvalVisitorPrecNormal().visit(parser.prog())


def evaluar_prec_invertida(archivo):
    input_stream = FileStream(archivo)
    lexer = ExprPrecInvertidaLexer(input_stream)
    stream = CommonTokenStream(lexer)
    parser = ExprPrecInvertidaParser(stream)
    return EvalVisitorPrecInvertida().visit(parser.prog())


if __name__ == "__main__":
    archivo1 = "pruebas/prueba1.txt"
    archivo2 = "pruebas/prueba2.txt"

    print("Expresión:", open(archivo1).read().strip())
    print("Izquierda:", evaluar_izq(archivo1))
    print("Derecha:", evaluar_der(archivo1))

    print("\n--- PRUEBA 2 ---")
    print("Expresión:", open(archivo2).read().strip())
    print("Precedencia normal:", evaluar_prec_normal(archivo2))
    print("Precedencia invertida:", evaluar_prec_invertida(archivo2))
