grammar ExprIzq;

prog: expr EOF;

expr
    : expr op=('+'|'-') term   # AddSub
    | term                     # ToTerm
    ;

term
    : term op=('*'|'/') factor # MulDiv
    | factor                   # ToFactor
    ;

factor
    : NUMBER                   # Num
    | '(' expr ')'             # Parens
    ;

NUMBER: [0-9]+;
WS: [ \t\r\n]+ -> skip;
