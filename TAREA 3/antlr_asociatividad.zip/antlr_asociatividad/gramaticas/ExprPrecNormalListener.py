# Generated from ExprPrecNormal.g4 by ANTLR 4.9.2
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .ExprPrecNormalParser import ExprPrecNormalParser
else:
    from ExprPrecNormalParser import ExprPrecNormalParser

# This class defines a complete listener for a parse tree produced by ExprPrecNormalParser.
class ExprPrecNormalListener(ParseTreeListener):

    # Enter a parse tree produced by ExprPrecNormalParser#prog.
    def enterProg(self, ctx:ExprPrecNormalParser.ProgContext):
        pass

    # Exit a parse tree produced by ExprPrecNormalParser#prog.
    def exitProg(self, ctx:ExprPrecNormalParser.ProgContext):
        pass


    # Enter a parse tree produced by ExprPrecNormalParser#expr.
    def enterExpr(self, ctx:ExprPrecNormalParser.ExprContext):
        pass

    # Exit a parse tree produced by ExprPrecNormalParser#expr.
    def exitExpr(self, ctx:ExprPrecNormalParser.ExprContext):
        pass


    # Enter a parse tree produced by ExprPrecNormalParser#term.
    def enterTerm(self, ctx:ExprPrecNormalParser.TermContext):
        pass

    # Exit a parse tree produced by ExprPrecNormalParser#term.
    def exitTerm(self, ctx:ExprPrecNormalParser.TermContext):
        pass


    # Enter a parse tree produced by ExprPrecNormalParser#factor.
    def enterFactor(self, ctx:ExprPrecNormalParser.FactorContext):
        pass

    # Exit a parse tree produced by ExprPrecNormalParser#factor.
    def exitFactor(self, ctx:ExprPrecNormalParser.FactorContext):
        pass



del ExprPrecNormalParser