# Generated from ExprIzq.g4 by ANTLR 4.9.2
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .ExprIzqParser import ExprIzqParser
else:
    from ExprIzqParser import ExprIzqParser

# This class defines a complete generic visitor for a parse tree produced by ExprIzqParser.

class ExprIzqVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by ExprIzqParser#prog.
    def visitProg(self, ctx:ExprIzqParser.ProgContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ExprIzqParser#AddSub.
    def visitAddSub(self, ctx:ExprIzqParser.AddSubContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ExprIzqParser#ToTerm.
    def visitToTerm(self, ctx:ExprIzqParser.ToTermContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ExprIzqParser#ToFactor.
    def visitToFactor(self, ctx:ExprIzqParser.ToFactorContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ExprIzqParser#MulDiv.
    def visitMulDiv(self, ctx:ExprIzqParser.MulDivContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ExprIzqParser#Num.
    def visitNum(self, ctx:ExprIzqParser.NumContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ExprIzqParser#Parens.
    def visitParens(self, ctx:ExprIzqParser.ParensContext):
        return self.visitChildren(ctx)



del ExprIzqParser