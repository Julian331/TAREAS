# Generated from ExprPrecNormal.g4 by ANTLR 4.9.2
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .ExprPrecNormalParser import ExprPrecNormalParser
else:
    from ExprPrecNormalParser import ExprPrecNormalParser

# This class defines a complete generic visitor for a parse tree produced by ExprPrecNormalParser.

class ExprPrecNormalVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by ExprPrecNormalParser#prog.
    def visitProg(self, ctx:ExprPrecNormalParser.ProgContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ExprPrecNormalParser#expr.
    def visitExpr(self, ctx:ExprPrecNormalParser.ExprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ExprPrecNormalParser#term.
    def visitTerm(self, ctx:ExprPrecNormalParser.TermContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ExprPrecNormalParser#factor.
    def visitFactor(self, ctx:ExprPrecNormalParser.FactorContext):
        return self.visitChildren(ctx)



del ExprPrecNormalParser