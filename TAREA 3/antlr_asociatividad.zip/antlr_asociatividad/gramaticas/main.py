from antlr4 import *

# IZQUIERDA
from gramaticas.ExprIzqLexer import ExprIzqLexer
from gramaticas.ExprIzqParser import ExprIzqParser
from visitor import EvalVisitorIzq

# DERECHA
from gramaticas.ExprDerLexer import ExprDerLexer
from gramaticas.ExprDerParser import ExprDerParser
from visitor import EvalVisitorDer


def evaluar_izq(archivo):
    input_stream = FileStream(archivo)
    lexer = ExprIzqLexer(input_stream)
    stream = CommonTokenStream(lexer)
    parser = ExprIzqParser(stream)
    tree = parser.prog()
    return EvalVisitorIzq().visit(tree)


def evaluar_der(archivo):
    input_stream = FileStream(archivo)
    lexer = ExprDerLexer(input_stream)
    stream = CommonTokenStream(lexer)
    parser = ExprDerParser(stream)
    tree = parser.prog()
    return EvalVisitorDer().visit(tree)


if __name__ == "__main__":
    archivo = "pruebas/prueba1.txt"

    print("Expresión:", open(archivo).read().strip())

    print("Izquierda:", evaluar_izq(archivo))
    print("Derecha:", evaluar_der(archivo))

from gramaticas.ExprPrecNormalLexer import ExprPrecNormalLexer
from gramaticas.ExprPrecNormalParser import ExprPrecNormalParser
from visitor import EvalVisitorPrecNormal

from gramaticas.ExprPrecInvertidaLexer import ExprPrecInvertidaLexer
from gramaticas.ExprPrecInvertidaParser import ExprPrecInvertidaParser
from visitor import EvalVisitorPrecInvertida

def evaluar_prec_normal(archivo):
    input_stream = FileStream(archivo)
    lexer = ExprPrecNormalLexer(input_stream)
    stream = CommonTokenStream(lexer)
    parser = ExprPrecNormalParser(stream)
    tree = parser.prog()
    return EvalVisitorPrecNormal().visit(tree)


def evaluar_prec_invertida(archivo):
    input_stream = FileStream(archivo)
    lexer = ExprPrecInvertidaLexer(input_stream)
    stream = CommonTokenStream(lexer)
    parser = ExprPrecInvertidaParser(stream)
    tree = parser.prog()
    return EvalVisitorPrecInvertida().visit(tree)

print("\n--- PRUEBA 2 ---")
archivo2 = "pruebas/prueba2.txt"

print("Expresión:", open(archivo2).read().strip())
print("Precedencia normal:", evaluar_prec_normal(archivo2))
print("Precedencia invertida:", evaluar_prec_invertida(archivo2))
