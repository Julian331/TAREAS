grammar ExprDer;

prog: expr EOF;

expr
    : term ('+' expr)?   # AddRight
    | term ('-' expr)?   # SubRight
    ;

term
    : factor ('*' term)? # MulRight
    | factor ('/' term)? # DivRight
    ;

factor
    : NUMBER
    | '(' expr ')'
    ;

NUMBER: [0-9]+;
WS: [ \t\r\n]+ -> skip;
