# Generated from ExprPrecInvertida.g4 by ANTLR 4.9.2
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .ExprPrecInvertidaParser import ExprPrecInvertidaParser
else:
    from ExprPrecInvertidaParser import ExprPrecInvertidaParser

# This class defines a complete generic visitor for a parse tree produced by ExprPrecInvertidaParser.

class ExprPrecInvertidaVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by ExprPrecInvertidaParser#prog.
    def visitProg(self, ctx:ExprPrecInvertidaParser.ProgContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ExprPrecInvertidaParser#expr.
    def visitExpr(self, ctx:ExprPrecInvertidaParser.ExprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ExprPrecInvertidaParser#term.
    def visitTerm(self, ctx:ExprPrecInvertidaParser.TermContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ExprPrecInvertidaParser#factor.
    def visitFactor(self, ctx:ExprPrecInvertidaParser.FactorContext):
        return self.visitChildren(ctx)



del ExprPrecInvertidaParser