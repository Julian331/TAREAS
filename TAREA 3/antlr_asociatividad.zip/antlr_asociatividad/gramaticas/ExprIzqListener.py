# Generated from ExprIzq.g4 by ANTLR 4.9.2
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .ExprIzqParser import ExprIzqParser
else:
    from ExprIzqParser import ExprIzqParser

# This class defines a complete listener for a parse tree produced by ExprIzqParser.
class ExprIzqListener(ParseTreeListener):

    # Enter a parse tree produced by ExprIzqParser#prog.
    def enterProg(self, ctx:ExprIzqParser.ProgContext):
        pass

    # Exit a parse tree produced by ExprIzqParser#prog.
    def exitProg(self, ctx:ExprIzqParser.ProgContext):
        pass


    # Enter a parse tree produced by ExprIzqParser#AddSub.
    def enterAddSub(self, ctx:ExprIzqParser.AddSubContext):
        pass

    # Exit a parse tree produced by ExprIzqParser#AddSub.
    def exitAddSub(self, ctx:ExprIzqParser.AddSubContext):
        pass


    # Enter a parse tree produced by ExprIzqParser#ToTerm.
    def enterToTerm(self, ctx:ExprIzqParser.ToTermContext):
        pass

    # Exit a parse tree produced by ExprIzqParser#ToTerm.
    def exitToTerm(self, ctx:ExprIzqParser.ToTermContext):
        pass


    # Enter a parse tree produced by ExprIzqParser#ToFactor.
    def enterToFactor(self, ctx:ExprIzqParser.ToFactorContext):
        pass

    # Exit a parse tree produced by ExprIzqParser#ToFactor.
    def exitToFactor(self, ctx:ExprIzqParser.ToFactorContext):
        pass


    # Enter a parse tree produced by ExprIzqParser#MulDiv.
    def enterMulDiv(self, ctx:ExprIzqParser.MulDivContext):
        pass

    # Exit a parse tree produced by ExprIzqParser#MulDiv.
    def exitMulDiv(self, ctx:ExprIzqParser.MulDivContext):
        pass


    # Enter a parse tree produced by ExprIzqParser#Num.
    def enterNum(self, ctx:ExprIzqParser.NumContext):
        pass

    # Exit a parse tree produced by ExprIzqParser#Num.
    def exitNum(self, ctx:ExprIzqParser.NumContext):
        pass


    # Enter a parse tree produced by ExprIzqParser#Parens.
    def enterParens(self, ctx:ExprIzqParser.ParensContext):
        pass

    # Exit a parse tree produced by ExprIzqParser#Parens.
    def exitParens(self, ctx:ExprIzqParser.ParensContext):
        pass



del ExprIzqParser