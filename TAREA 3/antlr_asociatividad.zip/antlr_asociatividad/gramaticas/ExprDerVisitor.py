# Generated from ExprDer.g4 by ANTLR 4.9.2
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .ExprDerParser import ExprDerParser
else:
    from ExprDerParser import ExprDerParser

# This class defines a complete generic visitor for a parse tree produced by ExprDerParser.

class ExprDerVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by ExprDerParser#prog.
    def visitProg(self, ctx:ExprDerParser.ProgContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ExprDerParser#AddRight.
    def visitAddRight(self, ctx:ExprDerParser.AddRightContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ExprDerParser#SubRight.
    def visitSubRight(self, ctx:ExprDerParser.SubRightContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ExprDerParser#MulRight.
    def visitMulRight(self, ctx:ExprDerParser.MulRightContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ExprDerParser#DivRight.
    def visitDivRight(self, ctx:ExprDerParser.DivRightContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ExprDerParser#factor.
    def visitFactor(self, ctx:ExprDerParser.FactorContext):
        return self.visitChildren(ctx)



del ExprDerParser