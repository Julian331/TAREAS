# Generated from ExprDer.g4 by ANTLR 4.9.2
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .ExprDerParser import ExprDerParser
else:
    from ExprDerParser import ExprDerParser

# This class defines a complete listener for a parse tree produced by ExprDerParser.
class ExprDerListener(ParseTreeListener):

    # Enter a parse tree produced by ExprDerParser#prog.
    def enterProg(self, ctx:ExprDerParser.ProgContext):
        pass

    # Exit a parse tree produced by ExprDerParser#prog.
    def exitProg(self, ctx:ExprDerParser.ProgContext):
        pass


    # Enter a parse tree produced by ExprDerParser#AddRight.
    def enterAddRight(self, ctx:ExprDerParser.AddRightContext):
        pass

    # Exit a parse tree produced by ExprDerParser#AddRight.
    def exitAddRight(self, ctx:ExprDerParser.AddRightContext):
        pass


    # Enter a parse tree produced by ExprDerParser#SubRight.
    def enterSubRight(self, ctx:ExprDerParser.SubRightContext):
        pass

    # Exit a parse tree produced by ExprDerParser#SubRight.
    def exitSubRight(self, ctx:ExprDerParser.SubRightContext):
        pass


    # Enter a parse tree produced by ExprDerParser#MulRight.
    def enterMulRight(self, ctx:ExprDerParser.MulRightContext):
        pass

    # Exit a parse tree produced by ExprDerParser#MulRight.
    def exitMulRight(self, ctx:ExprDerParser.MulRightContext):
        pass


    # Enter a parse tree produced by ExprDerParser#DivRight.
    def enterDivRight(self, ctx:ExprDerParser.DivRightContext):
        pass

    # Exit a parse tree produced by ExprDerParser#DivRight.
    def exitDivRight(self, ctx:ExprDerParser.DivRightContext):
        pass


    # Enter a parse tree produced by ExprDerParser#factor.
    def enterFactor(self, ctx:ExprDerParser.FactorContext):
        pass

    # Exit a parse tree produced by ExprDerParser#factor.
    def exitFactor(self, ctx:ExprDerParser.FactorContext):
        pass



del ExprDerParser