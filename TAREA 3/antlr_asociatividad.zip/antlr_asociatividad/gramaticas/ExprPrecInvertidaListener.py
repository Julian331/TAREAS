# Generated from ExprPrecInvertida.g4 by ANTLR 4.9.2
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .ExprPrecInvertidaParser import ExprPrecInvertidaParser
else:
    from ExprPrecInvertidaParser import ExprPrecInvertidaParser

# This class defines a complete listener for a parse tree produced by ExprPrecInvertidaParser.
class ExprPrecInvertidaListener(ParseTreeListener):

    # Enter a parse tree produced by ExprPrecInvertidaParser#prog.
    def enterProg(self, ctx:ExprPrecInvertidaParser.ProgContext):
        pass

    # Exit a parse tree produced by ExprPrecInvertidaParser#prog.
    def exitProg(self, ctx:ExprPrecInvertidaParser.ProgContext):
        pass


    # Enter a parse tree produced by ExprPrecInvertidaParser#expr.
    def enterExpr(self, ctx:ExprPrecInvertidaParser.ExprContext):
        pass

    # Exit a parse tree produced by ExprPrecInvertidaParser#expr.
    def exitExpr(self, ctx:ExprPrecInvertidaParser.ExprContext):
        pass


    # Enter a parse tree produced by ExprPrecInvertidaParser#term.
    def enterTerm(self, ctx:ExprPrecInvertidaParser.TermContext):
        pass

    # Exit a parse tree produced by ExprPrecInvertidaParser#term.
    def exitTerm(self, ctx:ExprPrecInvertidaParser.TermContext):
        pass


    # Enter a parse tree produced by ExprPrecInvertidaParser#factor.
    def enterFactor(self, ctx:ExprPrecInvertidaParser.FactorContext):
        pass

    # Exit a parse tree produced by ExprPrecInvertidaParser#factor.
    def exitFactor(self, ctx:ExprPrecInvertidaParser.FactorContext):
        pass



del ExprPrecInvertidaParser