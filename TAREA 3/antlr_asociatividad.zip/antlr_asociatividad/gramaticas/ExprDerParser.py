# Generated from ExprDer.g4 by ANTLR 4.9.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    with StringIO() as buf:
        buf.write("\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\n")
        buf.write("-\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\3\2\3\2\3\2\3\3\3\3")
        buf.write("\3\3\5\3\21\n\3\3\3\3\3\3\3\5\3\26\n\3\5\3\30\n\3\3\4")
        buf.write("\3\4\3\4\5\4\35\n\4\3\4\3\4\3\4\5\4\"\n\4\5\4$\n\4\3\5")
        buf.write("\3\5\3\5\3\5\3\5\5\5+\n\5\3\5\2\2\6\2\4\6\b\2\2\2/\2\n")
        buf.write("\3\2\2\2\4\27\3\2\2\2\6#\3\2\2\2\b*\3\2\2\2\n\13\5\4\3")
        buf.write("\2\13\f\7\2\2\3\f\3\3\2\2\2\r\20\5\6\4\2\16\17\7\3\2\2")
        buf.write("\17\21\5\4\3\2\20\16\3\2\2\2\20\21\3\2\2\2\21\30\3\2\2")
        buf.write("\2\22\25\5\6\4\2\23\24\7\4\2\2\24\26\5\4\3\2\25\23\3\2")
        buf.write("\2\2\25\26\3\2\2\2\26\30\3\2\2\2\27\r\3\2\2\2\27\22\3")
        buf.write("\2\2\2\30\5\3\2\2\2\31\34\5\b\5\2\32\33\7\5\2\2\33\35")
        buf.write("\5\6\4\2\34\32\3\2\2\2\34\35\3\2\2\2\35$\3\2\2\2\36!\5")
        buf.write("\b\5\2\37 \7\6\2\2 \"\5\6\4\2!\37\3\2\2\2!\"\3\2\2\2\"")
        buf.write("$\3\2\2\2#\31\3\2\2\2#\36\3\2\2\2$\7\3\2\2\2%+\7\t\2\2")
        buf.write("&\'\7\7\2\2\'(\5\4\3\2()\7\b\2\2)+\3\2\2\2*%\3\2\2\2*")
        buf.write("&\3\2\2\2+\t\3\2\2\2\t\20\25\27\34!#*")
        return buf.getvalue()


class ExprDerParser ( Parser ):

    grammarFileName = "ExprDer.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'+'", "'-'", "'*'", "'/'", "'('", "')'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "NUMBER", "WS" ]

    RULE_prog = 0
    RULE_expr = 1
    RULE_term = 2
    RULE_factor = 3

    ruleNames =  [ "prog", "expr", "term", "factor" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    NUMBER=7
    WS=8

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.9.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None



    class ProgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expr(self):
            return self.getTypedRuleContext(ExprDerParser.ExprContext,0)


        def EOF(self):
            return self.getToken(ExprDerParser.EOF, 0)

        def getRuleIndex(self):
            return ExprDerParser.RULE_prog

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProg" ):
                listener.enterProg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProg" ):
                listener.exitProg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProg" ):
                return visitor.visitProg(self)
            else:
                return visitor.visitChildren(self)




    def prog(self):

        localctx = ExprDerParser.ProgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_prog)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 8
            self.expr()
            self.state = 9
            self.match(ExprDerParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return ExprDerParser.RULE_expr

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class SubRightContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ExprDerParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def term(self):
            return self.getTypedRuleContext(ExprDerParser.TermContext,0)

        def expr(self):
            return self.getTypedRuleContext(ExprDerParser.ExprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSubRight" ):
                listener.enterSubRight(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSubRight" ):
                listener.exitSubRight(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSubRight" ):
                return visitor.visitSubRight(self)
            else:
                return visitor.visitChildren(self)


    class AddRightContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ExprDerParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def term(self):
            return self.getTypedRuleContext(ExprDerParser.TermContext,0)

        def expr(self):
            return self.getTypedRuleContext(ExprDerParser.ExprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAddRight" ):
                listener.enterAddRight(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAddRight" ):
                listener.exitAddRight(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAddRight" ):
                return visitor.visitAddRight(self)
            else:
                return visitor.visitChildren(self)



    def expr(self):

        localctx = ExprDerParser.ExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_expr)
        self._la = 0 # Token type
        try:
            self.state = 21
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,2,self._ctx)
            if la_ == 1:
                localctx = ExprDerParser.AddRightContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 11
                self.term()
                self.state = 14
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==ExprDerParser.T__0:
                    self.state = 12
                    self.match(ExprDerParser.T__0)
                    self.state = 13
                    self.expr()


                pass

            elif la_ == 2:
                localctx = ExprDerParser.SubRightContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 16
                self.term()
                self.state = 19
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==ExprDerParser.T__1:
                    self.state = 17
                    self.match(ExprDerParser.T__1)
                    self.state = 18
                    self.expr()


                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class TermContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return ExprDerParser.RULE_term

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class DivRightContext(TermContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ExprDerParser.TermContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def factor(self):
            return self.getTypedRuleContext(ExprDerParser.FactorContext,0)

        def term(self):
            return self.getTypedRuleContext(ExprDerParser.TermContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDivRight" ):
                listener.enterDivRight(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDivRight" ):
                listener.exitDivRight(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDivRight" ):
                return visitor.visitDivRight(self)
            else:
                return visitor.visitChildren(self)


    class MulRightContext(TermContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ExprDerParser.TermContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def factor(self):
            return self.getTypedRuleContext(ExprDerParser.FactorContext,0)

        def term(self):
            return self.getTypedRuleContext(ExprDerParser.TermContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMulRight" ):
                listener.enterMulRight(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMulRight" ):
                listener.exitMulRight(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMulRight" ):
                return visitor.visitMulRight(self)
            else:
                return visitor.visitChildren(self)



    def term(self):

        localctx = ExprDerParser.TermContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_term)
        self._la = 0 # Token type
        try:
            self.state = 33
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,5,self._ctx)
            if la_ == 1:
                localctx = ExprDerParser.MulRightContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 23
                self.factor()
                self.state = 26
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==ExprDerParser.T__2:
                    self.state = 24
                    self.match(ExprDerParser.T__2)
                    self.state = 25
                    self.term()


                pass

            elif la_ == 2:
                localctx = ExprDerParser.DivRightContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 28
                self.factor()
                self.state = 31
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==ExprDerParser.T__3:
                    self.state = 29
                    self.match(ExprDerParser.T__3)
                    self.state = 30
                    self.term()


                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class FactorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NUMBER(self):
            return self.getToken(ExprDerParser.NUMBER, 0)

        def expr(self):
            return self.getTypedRuleContext(ExprDerParser.ExprContext,0)


        def getRuleIndex(self):
            return ExprDerParser.RULE_factor

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFactor" ):
                listener.enterFactor(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFactor" ):
                listener.exitFactor(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFactor" ):
                return visitor.visitFactor(self)
            else:
                return visitor.visitChildren(self)




    def factor(self):

        localctx = ExprDerParser.FactorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_factor)
        try:
            self.state = 40
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [ExprDerParser.NUMBER]:
                self.enterOuterAlt(localctx, 1)
                self.state = 35
                self.match(ExprDerParser.NUMBER)
                pass
            elif token in [ExprDerParser.T__4]:
                self.enterOuterAlt(localctx, 2)
                self.state = 36
                self.match(ExprDerParser.T__4)
                self.state = 37
                self.expr()
                self.state = 38
                self.match(ExprDerParser.T__5)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





