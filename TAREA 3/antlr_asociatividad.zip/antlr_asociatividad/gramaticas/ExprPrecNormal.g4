grammar ExprPrecNormal;

prog: expr EOF;

expr
    : expr op=('+'|'-') term
    | term
    ;

term
    : term op=('*'|'/') factor
    | factor
    ;

factor
    : NUMBER
    | '(' expr ')'
    ;

NUMBER: [0-9]+;
WS: [ \t\r\n]+ -> skip;
