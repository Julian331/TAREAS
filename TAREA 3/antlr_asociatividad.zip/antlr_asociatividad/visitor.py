from gramaticas.ExprIzqVisitor import ExprIzqVisitor

class EvalVisitorIzq(ExprIzqVisitor):

    def visitProg(self, ctx):
        return self.visit(ctx.expr())

    def visitAddSub(self, ctx):
        left = self.visit(ctx.expr())
        right = self.visit(ctx.term())

        if ctx.op.text == '+':
            return left + right
        else:
            return left - right

    def visitMulDiv(self, ctx):
        left = self.visit(ctx.term())
        right = self.visit(ctx.factor())

        if ctx.op.text == '*':
            return left * right
        else:
            return left / right

    def visitNum(self, ctx):
        return int(ctx.getText())

    def visitParens(self, ctx):
        return self.visit(ctx.expr())


from gramaticas.ExprDerVisitor import ExprDerVisitor

class EvalVisitorDer(ExprDerVisitor):

    def visitProg(self, ctx):
        return self.visit(ctx.expr())

    def visitAddRight(self, ctx):
        left = self.visit(ctx.term())
        if ctx.expr():
            return left + self.visit(ctx.expr())
        return left

    def visitSubRight(self, ctx):
        left = self.visit(ctx.term())
        if ctx.expr():
            return left - self.visit(ctx.expr())
        return left

    def visitMulRight(self, ctx):
        left = self.visit(ctx.factor())
        if ctx.term():
            return left * self.visit(ctx.term())
        return left

    def visitDivRight(self, ctx):
        left = self.visit(ctx.factor())
        if ctx.term():
            return left / self.visit(ctx.term())
        return left

    def visitFactor(self, ctx):
        if ctx.NUMBER():
            return int(ctx.getText())
        return self.visit(ctx.expr())

from gramaticas.ExprPrecNormalVisitor import ExprPrecNormalVisitor

class EvalVisitorPrecNormal(ExprPrecNormalVisitor):

    def visitProg(self, ctx):
        return self.visit(ctx.expr())

    def visitExpr(self, ctx):
        if ctx.getChildCount() == 3:
            left = self.visit(ctx.expr())
            right = self.visit(ctx.term())
            if ctx.op.text == '+':
                return left + right
            else:
                return left - right
        return self.visit(ctx.term())

    def visitTerm(self, ctx):
        if ctx.getChildCount() == 3:
            left = self.visit(ctx.term())
            right = self.visit(ctx.factor())
            if ctx.op.text == '*':
                return left * right
            else:
                return left / right
        return self.visit(ctx.factor())

    def visitFactor(self, ctx):
        if ctx.NUMBER():
            return int(ctx.getText())
        return self.visit(ctx.expr())
from gramaticas.ExprPrecInvertidaVisitor import ExprPrecInvertidaVisitor

class EvalVisitorPrecInvertida(ExprPrecInvertidaVisitor):

    def visitProg(self, ctx):
        return self.visit(ctx.expr())

    def visitExpr(self, ctx):
        if ctx.getChildCount() == 3:
            left = self.visit(ctx.expr())
            right = self.visit(ctx.term())
            if ctx.op.text == '*':
                return left * right
            else:
                return left / right
        return self.visit(ctx.term())

    def visitTerm(self, ctx):
        if ctx.getChildCount() == 3:
            left = self.visit(ctx.term())
            right = self.visit(ctx.factor())
            if ctx.op.text == '+':
                return left + right
            else:
                return left - right
        return self.visit(ctx.factor())

    def visitFactor(self, ctx):
        if ctx.NUMBER():
            return int(ctx.getText())
        return self.visit(ctx.expr())
